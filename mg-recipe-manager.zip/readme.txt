=== MG Recipe Manager ===
Contributors: mastergraphiks
Tags: recipe, food, cooking, custom post type
Requires at least: 5.0
Tested up to: 6.6
Stable tag: 1.0.0
Requires PHP: 7.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create and manage recipes with a custom post type and display random recipes using a shortcode.

== Description ==

MG Recipe Manager Plugin allows you to easily create and manage recipes on your WordPress website. It provides a custom post type for recipes with fields for title, description, ingredients, instructions, image, category, and tags.

Features:
* Custom "Recipe" post type
* Custom fields for ingredients and instructions
* Shortcode [mg_recipe_manager] to display a random recipe
* Admin menu for viewing all recipes and managing settings
* Custom template for single recipe display
* Recipe categories and tags

This plugin is perfect for food bloggers, recipe websites, and anyone who wants to share recipes on their WordPress site.

== Installation ==

1. Upload the `mg-recipe-manager` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Start creating recipes using the new "Recipes" menu in your admin panel

== Usage ==

To display a random recipe on your site, use the following shortcode:

[mg_recipe_manager]

== Changelog ==

= 1.0.0 =
* Initial release
* Custom "Recipe" post type with custom fields for ingredients and instructions
* Recipe categories and tags
* Shortcode to display random recipes
* Custom template for single recipe display
* Admin page for viewing recent recipes
* Basic settings page with option to display recipe author

== Upgrade Notice ==

= 1.0.0 =
Initial release of the MG Recipe Manager.

== Additional Information ==

Plugin Name: MG Recipe Manager
Plugin URI: https://github.com/mastergraphiks/mg-recipe-manager
Description: A plugin to create and manage recipes with a custom post type and shortcode to display random recipes.
Version: 1.0.0
Requires at least: 5.0
Tested up to: 5.9
Requires PHP: 7.2
Author: Syed Ali
Author URI: https://mastergraphiks.no
License: GPL v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The MG Recipe Manager allows users to easily create and manage recipes on their WordPress website. It provides a custom post type for recipes with fields for title, description, ingredients, instructions, image, category, and tags. The plugin also includes a shortcode to display random recipes, a custom template for single recipe display, and an admin menu for viewing all recipes and managing settings.

Key features:
- Custom "Recipe" post type
- Custom fields for ingredients and instructions
- Recipe categories and tags
- Shortcode [mg_recipe_manager] to display random recipes
- Custom template for single recipe display
- Admin menu for viewing recent recipes and managing settings
- Basic settings page with option to display recipe author

This plugin is perfect for food bloggers, recipe websites, and anyone who wants to share recipes on their WordPress site.